#===============================================================================
# arm-none-eabi-gcc.cmake —— CMake 交叉编译工具链文件（Cortex-M3 / F103）
#===============================================================================
#
# 【这个文件干什么？】
#   CMake 默认以为你要编「给本机跑的 x86 程序」。
#   要编给 STM32F103（Cortex-M3）跑的程序，必须提前告诉它：
#     · 用哪个编译器
#     · 目标是什么架构
#     · 怎么把 .elf 转成 .hex / .bin
#
# 【关键】这些设置必须在 project() 之前生效，
#        所以写在工具链文件里，用 -DCMAKE_TOOLCHAIN_FILE 传给 CMake，
#        而不是写在 CMakeLists.txt 里。
#
# 【和 Keil 的对应关系】
#   Keil 的 "Target → 器件选择" + "C/C++ → 预定义宏" 里的架构部分
#   就等价于这里的 -mcpu / -mthumb / -mfloat-abi。
#===============================================================================

set(CMAKE_SYSTEM_NAME      Generic)     # Generic = 通用裸机（没有操作系统）
set(CMAKE_SYSTEM_PROCESSOR arm)

# ── 交叉编译器前缀 ────────────────────────────────────────────────────
# CMake 会自动拼出 arm-none-eabi-gcc / g++ / ar / objcopy / size / objdump
set(TOOLCHAIN_PREFIX arm-none-eabi-)

# 如果 arm-none-eabi-gcc 不在 PATH 里，把下面这行的注释去掉并改成实际路径：
#   set(TOOLCHAIN_PREFIX "D:/ST/gcc-arm-none-eabi/bin/arm-none-eabi-")
# ⚠️ 用正斜杠 /，不要用反斜杠 \

set(CMAKE_C_COMPILER   ${TOOLCHAIN_PREFIX}gcc)
set(CMAKE_ASM_COMPILER ${TOOLCHAIN_PREFIX}gcc)
set(CMAKE_CXX_COMPILER ${TOOLCHAIN_PREFIX}g++)
set(CMAKE_AR           ${TOOLCHAIN_PREFIX}ar)
set(CMAKE_OBJCOPY      ${TOOLCHAIN_PREFIX}objcopy)
set(CMAKE_OBJDUMP      ${TOOLCHAIN_PREFIX}objdump)
set(CMAKE_SIZE         ${TOOLCHAIN_PREFIX}size)
set(CMAKE_RANLIB       ${TOOLCHAIN_PREFIX}ranlib)

# ── 目标架构 ──────────────────────────────────────────────────────────
# F103C8T6 是 Cortex-M3，**没有硬件浮点单元**。
#
# 🚨 所以这里一个浮点选项都不能加：
#      -mfpu=...      → 链接时报 "selected processor does not support"
#      -mfloat-abi=hard → 同上
#   想浮点快只能靠整数运算或者定点数，这是 F103 的硬限制。
#   （F407 是 Cortex-M4F 才有 FPU）
set(TARGET_FLAGS "-mcpu=cortex-m3 -mthumb")

set(CMAKE_C_FLAGS_INIT          "${TARGET_FLAGS}")
set(CMAKE_CXX_FLAGS_INIT        "${TARGET_FLAGS}")
# 汇编文件要先过 C 预处理器，否则 #include / #define 不生效
set(CMAKE_ASM_FLAGS_INIT        "${TARGET_FLAGS} -x assembler-with-cpp")
set(CMAKE_EXE_LINKER_FLAGS_INIT "${TARGET_FLAGS}")

# ── 关于可执行文件后缀 .elf ───────────────────────────────────────────
# ⚠️ 别在这里设 CMAKE_EXECUTABLE_SUFFIX，**设了也没用**！
#
# 实测结论（2026-10-11）：在此处 set(CMAKE_EXECUTABLE_SUFFIX ".elf") 之后，
# 产物依然叫 `stm32-led-on`（没有后缀）。原因是 CMake 随后加载
#     Modules/Platform/Generic.cmake
# 时有一句
#     set(CMAKE_EXECUTABLE_SUFFIX "")
# 把工具链文件里设的值覆盖掉了 —— 裸机平台按设计就是空后缀。
#
# 正确做法是设 target 的 SUFFIX 属性，写在 CMakeLists.txt 里
# （add_executable 之后）：
#     set_target_properties(${PROJECT_NAME} PROPERTIES SUFFIX ".elf")
# target 属性在生成阶段最后生效，不会被平台文件覆盖。
#
# 留这段注释是为了以后你别再踩同一个坑 —— 我第一次就是这么写错的。

# ── 绕过 CMake 的编译器自检 ───────────────────────────────────────────
# 交叉编译时 CMake 会试编一个可执行文件来验证编译器，
# 但产出的 ARM 程序在 Windows 上跑不了，自检必然失败。
#
# 做法一（现代 CMake 的标准做法，推荐）：
#   把自检改成「编译成静态库」—— 静态库不需要链接，
#   也就不需要链接脚本和启动文件，自检必然成功。
set(CMAKE_TRY_COMPILE_TARGET_TYPE STATIC_LIBRARY)

# 做法二（老写法，双保险）：
#   直接告诉 CMake「编译器没问题」，跳过检查。
set(CMAKE_C_COMPILER_WORKS   1)
set(CMAKE_CXX_COMPILER_WORKS 1)
set(CMAKE_ASM_COMPILER_WORKS 1)

# ── 只在目标环境里找库和头文件，别在 Windows 里乱找 ──────────────────
set(CMAKE_FIND_ROOT_PATH_MODE_PROGRAM NEVER)
set(CMAKE_FIND_ROOT_PATH_MODE_LIBRARY ONLY)
set(CMAKE_FIND_ROOT_PATH_MODE_INCLUDE ONLY)
set(CMAKE_FIND_ROOT_PATH_MODE_PACKAGE ONLY)
